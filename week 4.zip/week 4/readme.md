# Week 4 – SIEM in Practice: Splunk, Log Ingestion and Security Monitoring

## Overview

This project documents my Week 4 Cybersecurity practical, focusing on Security Information and Event Management (SIEM) using **Splunk Enterprise**.

The objective was to build a centralised security monitoring environment, collect logs from Windows and Linux systems, simulate security-related activities, analyse events using Search Processing Language (SPL), configure detection alerts and investigate potential security incidents.

## Objectives

- Understand SIEM architecture and its importance in cybersecurity.
- Install and configure Splunk Enterprise.
- Collect Windows Security, Sysmon and Linux authentication logs.
- Perform security testing using Hydra and Nmap.
- Analyse security events using SPL.
- Create detection searches and scheduled alerts.
- Build a cybersecurity monitoring dashboard.
- Perform basic SOC alert triage and investigation.

## Laboratory Environment

| Component | Configuration |
|---|---|
| Host OS | Windows 11 |
| Virtualisation | Oracle VirtualBox |
| SIEM Platform | Splunk Enterprise 10.6.1.1 |
| SIEM Server | Ubuntu 26.04.1 LTS |
| Monitoring System | Windows 10 VM |
| Testing System | Kali Linux |
| Network | 192.168.50.0/24 |
| Splunk Receiving Port | 9997 |
| Splunk Index | lab |

### Virtual Machine IP Addresses

| Virtual Machine | IP Address |
|---|---|
| Ubuntu (Splunk Server) | 192.168.50.5 |
| Windows 10 | 192.168.50.6 |
| Kali Linux | 192.168.50.4 |

## Task 1 – Splunk Enterprise Installation

Splunk Enterprise was installed on the Ubuntu virtual machine.

The configuration involved:

- Installing Splunk Enterprise.
- Starting and verifying the Splunk service.
- Accessing the Splunk Web interface.
- Creating a dedicated index named `lab`.

Splunk Web:

`http://127.0.0.1:8000`

## Task 2 – Log Ingestion and Forwarding

The objective was to centralise logs from Windows and Ubuntu systems.

### Windows Log Collection

The Splunk Universal Forwarder was installed on the Windows VM and configured to forward logs to the Ubuntu Splunk server.

The following event logs were collected:

- Windows Security Event Log.
- Microsoft Sysmon Operational Event Log.

The forwarder was configured using:

- `inputs.conf`
- `outputs.conf`

The Universal Forwarder service account was granted Event Log Readers permissions.

### Ubuntu Log Collection

Ubuntu authentication logs were monitored using:

`/var/log/auth.log`

The source type was configured as:

`linux_secure`

The Splunk service account was granted the required permissions to access the log file.

### Verification Search

```spl
index=lab sourcetype=linux_secure
```

Windows Security, Sysmon and Ubuntu authentication events were successfully indexed in Splunk.

## Task 3 – SIEM Architecture and Platform Selection

Splunk was selected as the primary SIEM platform for this practical. The lecturer confirmed that using one SIEM solution was sufficient.

The implemented architecture consisted of:

1. **Data Sources:** Windows Security logs, Sysmon logs and Ubuntu authentication logs.
2. **Log Collection:** Splunk Universal Forwarder and Ubuntu log monitoring.
3. **Centralised Storage:** Splunk Enterprise and the `lab` index.
4. **Analysis:** SPL searches and event filtering.
5. **Alerting:** Scheduled detection alerts.
6. **Visualisation:** Cybersecurity monitoring dashboard.

Wazuh was not deployed because Splunk alone fulfilled the practical requirements.

## Task 4 – Attack Simulation and Event Investigation

Two security activities were performed using Kali Linux against the laboratory environment.

### 1. SSH Brute-Force Simulation Using Hydra

Hydra was used to simulate SSH password guessing against the Ubuntu VM.

A wordlist containing 20 incorrect passwords was created.

Command:

```bash
hydra -l kirthikaa -P ssh-wordlist.txt -t 2 -W 3 -V ssh://192.168.50.5
```

**Results:**

- 20 password attempts were generated.
- No valid passwords were discovered.
- Failed authentication events were recorded in Ubuntu's authentication log.
- The source IP was `192.168.50.4`.
- The targeted username was `kirthikaa`.

Splunk search:

```spl
index=lab sourcetype=linux_secure "Failed password"
```

### 2. Nmap SYN Port Scanning

Nmap was used to perform a SYN scan against the Ubuntu VM.

Command:

```bash
sudo nmap -sS -p 22,80,443,8000,8089 192.168.50.5
```

**Results:**

| Port | Service | Status |
|---|---|---|
| 22 | SSH | Open |
| 80 | HTTP | Open |
| 443 | HTTPS | Closed |
| 8000 | HTTP-alt | Open |
| 8089 | Unknown | Open |

Tcpdump was used to capture incoming SYN packets on Ubuntu. The captured output was saved as `nmap-syn.log` and monitored in Splunk using the custom sourcetype `nmap_syn`.

Five SYN packet events from Kali to Ubuntu were identified.

## Task 5 – SPL Detections and Security Monitoring

Five SPL detection searches were developed to monitor different security activities.

### Detection Searches

| No. | Detection | Event Source | Purpose |
|---|---|---|---|
| 1 | Windows Failed Logons | Event ID 4625 | Identify failed Windows authentication attempts. |
| 2 | PowerShell Execution | Sysmon Event ID 1 | Monitor PowerShell process execution. |
| 3 | New User Account Creation | Event ID 4720 | Identify newly created Windows accounts. |
| 4 | SSH Failed Login Attempts | Ubuntu `linux_secure` | Identify failed SSH authentication attempts. |
| 5 | Rare Parent-Child Process Pairs | Sysmon Event ID 1 | Identify uncommon process relationships. |

### Scheduled Alerts

Two scheduled alerts were created and enabled.

| Alert | Purpose | Schedule |
|---|---|---|
| Windows Failed Logon Detection | Detect repeated Windows login failures. | Every 5 minutes |
| SSH Brute Force Detection | Detect repeated failed SSH authentication attempts. | Every 5 minutes |

Both alerts were configured with result thresholds and the Add to Triggered Alerts action.

### Cybersecurity Monitoring Dashboard

A dashboard named **Cybersecurity Monitoring Dashboard** was created using Splunk Dashboard Studio.

It contained four panels:

1. Windows Failed Logons by User.
2. PowerShell Process Executions.
3. Windows New User Account Creation.
4. SSH Brute Force Attempts by Source IP.

The dashboard provided a centralised view of important security events collected from the laboratory systems.

## Task 6 – Alert Triage and Investigation

Three security alerts were selected for investigation.

Each investigation considered who performed the activity, what happened, when it occurred, where it originated, why it happened, the verdict and the recommended next step.

### Alert 1 – Windows Failed Logon

| Field | Finding |
|---|---|
| Event ID | 4625 |
| Username | Kirthikaa |
| Host | DESKTOP-CV7MUF1 |
| Source IP | 127.0.0.1 |
| Logon Type | 2 – Interactive |
| Failure | Incorrect password |
| Verdict | Undetermined – likely benign |

The event indicated an unsuccessful interactive login attempt against the local Windows account. The exact reason for the failed login could not be confirmed.

**Recommended Action:** Monitor for repeated failed login attempts and investigate further if similar events occur.

### Alert 2 – SSH Brute-Force Detection

| Field | Finding |
|---|---|
| Source IP | 192.168.50.4 |
| Destination IP | 192.168.50.5 |
| Username | kirthikaa |
| Failed Attempts | 23 |
| Verdict | True Positive – Authorised Testing |

The investigation identified 23 failed SSH password attempts originating from Kali Linux. Hydra was intentionally used as part of the authorised laboratory exercise.

**Recommended Action:** Document the activity as authorised testing and retain the logs as evidence.

### Alert 3 – Windows New User Creation

| Field | Finding |
|---|---|
| Event ID | 4720 |
| Host | DESKTOP-CV7MUF1 |
| Created Accounts | LabTest2, SysmonLabUser |
| Created By | Kirthikaa |
| Verdict | True Positive – Authorised Testing |

Two new Windows user accounts were identified. Both accounts were intentionally created during the Windows/Sysmon practical.

**Recommended Action:** Document the activity and verify that the test accounts are no longer required.

## SPL Commands Practised

The following SPL commands were used during the practical:

| Command | Purpose |
|---|---|
| `search` | Search for specific events. |
| `table` | Display selected fields. |
| `fields` | Include or exclude fields. |
| `stats` | Calculate statistics. |
| `eval` | Create or modify fields. |
| `where` | Filter results using conditions. |
| `sort` | Sort search results. |
| `head` | Display the first results. |
| `tail` | Display the last results. |
| `dedup` | Remove duplicate results. |
| `rex` | Extract fields using regular expressions. |
| `rename` | Rename fields. |
| `top` | Identify frequently occurring values. |
| `rare` | Identify uncommon values. |
| `timechart` | Visualise event trends over time. |

## Key Learnings

Through this practical, I gained experience in:

- Understanding SIEM architecture and centralised log monitoring.
- Installing and configuring Splunk Enterprise.
- Configuring log forwarding from Windows systems.
- Monitoring Linux authentication logs.
- Generating security events using Hydra and Nmap.
- Writing SPL queries to investigate security events.
- Creating scheduled detection alerts.
- Developing dashboards for security monitoring.
- Investigating security alerts and documenting findings.
- Understanding the difference between True Positive and False Positive alerts.

## Challenges Encountered

Some challenges experienced during the practical included:

- Virtual machine freezing and performance issues.
- Splunk service permission problems.
- Windows Event Log access restrictions.
- Ubuntu authentication log permissions.
- Network connectivity between virtual machines.
- Extracting useful fields from raw XML events.
- Configuring dashboard time ranges correctly.

These challenges provided practical troubleshooting experience in a virtualised SIEM environment.

## Conclusion

Week 4 provided hands-on experience in building and operating a centralised SIEM environment using Splunk Enterprise.

The practical covered log ingestion, security event generation, SPL detection searches, scheduled alerts, dashboard development and SOC alert triage.

By completing the laboratory exercises, I developed a better understanding of how SIEM solutions help security analysts monitor systems, identify suspicious activities, investigate potential threats and support incident response.

---

**Project:** Week 4 – SIEM in Practice  
**Platform:** Splunk Enterprise  
**Environment:** Oracle VirtualBox  
**Focus:** Log Ingestion, Security Monitoring, Detection Engineering and Alert Triage
